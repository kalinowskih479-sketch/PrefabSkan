﻿PrefabScan 4.1 — Compile Fix

Cel: poprawka błędu kompilacji CS0266 w wersji 3.4.

Poprawka:
- OcrFallbackExtractor.cs: metoda lokalna RunFocus zwraca List<OcrWord>,
  podczas gdy RunTile zwraca IEnumerable<OcrWord>.
- Wynik RunTile jest teraz jawnie materializowany przez .ToList().
- Zmieniono wersję cache OCR na prefabscan-ocr-3.4.
- Tytuł aplikacji: PrefabScan 4.1 — Compile Fix.

Błędy CS0006 widoczne po CS0266 były błędami wtórnymi: biblioteka
SewerScan.Infrastructure.dll nie powstawała z powodu CS0266.

Wersja zachowuje optymalizacje wydajności 3.4.
