﻿PrefabScan 3.3 — Spatial Cell OCR

Zmiany względem 3.1:
- ujednolicono numer wersji w interfejsie i raporcie diagnostycznym,
- cache OCR podniesiony do 3.2.0 — pierwsza analiza wymusi świeży odczyt,
- raport diagnostyczny pokazuje liczbę studni, wpustów i rur,
- raport pokazuje liczbę studni kompletnych oraz kandydatów wymagających weryfikacji,
- przy każdej studni raportuje poziom pewności,
- zachowano zasadę Vision Pipeline: słaby kandydat OCR nie jest bezpowrotnie usuwany,
  lecz oznaczany do potwierdzenia na innym rysunku,
- dodano test regresyjny dla fałszywego wysokiego identyfikatora OCR (np. S95),
- ujednolicono identyfikator PrefabScan używany przy pobieraniu modeli Tesseract.

Najważniejszy cel 3.2:
nie ukrywać potencjalnych obiektów, ale wyraźnie odseparować wynik pewny od śmieci OCR.

Uruchomienie:
1. Otwórz PrefabScan.sln.
2. Ustaw SewerScan.UI jako projekt startowy.
3. Zbuduj rozwiązanie.
4. Uruchom program.
5. Wczytaj PZT + profile i wykonaj "Analizuj zestaw".
6. W razie rozbieżności wyeksportuj diagnostykę TXT.
