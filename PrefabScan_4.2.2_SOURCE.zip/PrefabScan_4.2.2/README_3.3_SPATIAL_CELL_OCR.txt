﻿PrefabScan 3.3 — Spatial Cell OCR
=================================

Cel wersji 3.3:
- nie tylko wykrywać oznaczenie studni, ale odczytać dane techniczne należące do tej samej studni.

Najważniejsze zmiany:
1. OCR globalny najpierw deduplikuje kandydatów studni.
2. Dla każdej wiarygodnej studni wykonywane są 3 lokalne przebiegi OCR:
   - 700x480 px / 5.40x: drobne DN i rzędne,
   - 1250x900 px / 4.60x: bloki opisowe,
   - 1050x1550 px / 4.15x: pionowa komórka profilu z rzędnymi i rurami.
3. Parser profilu przypisuje dane w komórce ograniczonej sąsiednimi studniami w osi X.
4. Zasięg pionowy komórki profilu zwiększono z 15% do 32% wysokości rysunku.
5. PZT używa większej komórki własności i reguły najbliższej studni.
6. Odrzucane są typowe zanieczyszczenia OCR rzędnymi, np. D59.93.
7. Cache OCR ma wersję 3.3.0 — pierwszy test musi wykonać świeży OCR.

Test praktyczny:
- użyć tego samego zestawu PZT + profil KS + profil KD co w teście 3.2,
- po analizie zapisać diagnostykę TXT,
- porównać: liczba prawdziwych studni, DN, rzędne góry/dna, wysokość, przejścia.
