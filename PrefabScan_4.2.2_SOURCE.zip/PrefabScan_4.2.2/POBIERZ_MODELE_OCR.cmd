﻿@echo off
setlocal
set "DEST=%~dp0src\SewerScan.UI\bin\Debug\net10.0-windows\tessdata"
if not exist "%DEST%" mkdir "%DEST%"
echo Pobieranie modelu OCR ENG...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing 'https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/eng.traineddata' -OutFile '%DEST%\eng.traineddata'"
echo Pobieranie modelu OCR POL...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing 'https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main/pol.traineddata' -OutFile '%DEST%\pol.traineddata'"
echo Gotowe. Modele OCR zapisano w: %DEST%
pause
