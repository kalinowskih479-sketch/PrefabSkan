@echo off
setlocal
cd /d "%~dp0"

echo ============================================
echo PrefabScan 4.1 - automatyczny test Batorego
echo ============================================
echo.

where dotnet >nul 2>nul
if errorlevel 1 (
  echo BLAD: nie znaleziono dotnet.exe w PATH.
  echo Otworz rozwiazanie w Visual Studio, zbuduj je i uruchom program przyciskiem TEST BATOREGO.
  pause
  exit /b 1
)

dotnet build PrefabScan.sln -c Debug
if errorlevel 1 (
  echo.
  echo KOMPILACJA NIEUDANA.
  pause
  exit /b 1
)

set EXE=src\SewerScan.UI\bin\Debug\net10.0-windows\SewerScan.UI.exe
if not exist "%EXE%" (
  echo BLAD: nie znaleziono %EXE%
  pause
  exit /b 1
)

echo.
echo Kompilacja OK. Uruchamiam automatyczny benchmark...
start "" "%EXE%" --benchmark
exit /b 0
