﻿@echo off
cd /d "%~dp0"
start "" "PrefabScan.sln"
