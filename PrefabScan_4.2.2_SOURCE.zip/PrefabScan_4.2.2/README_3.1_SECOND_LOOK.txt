﻿PrefabScan 3.1 — Vision Second-Look

Zmiany względem 3.0:
- render OCR zwiększony do 7600 px,
- globalny OCR pracuje w większej skali,
- po znalezieniu oznaczenia studni/wpustu wykonywany jest drugi lokalny OCR (zoom 4.2.25x),
- lokalny odczyt odzyskuje drobne DN, rzędne i opisy przy konkretnym obiekcie,
- filtr zanieczyszczeń identyfikatora odrzuca m.in. S3/2025,
- nowa wersja cache OCR 3.1 wymusza ponowną analizę dokumentów.

Uruchomienie: otwórz PrefabScan.sln, ustaw SewerScan.UI jako projekt startowy, kompiluj rozwiązanie, uruchom.
Pierwsza analiza będzie wolniejsza — wykonywane są lokalne przebiegi OCR.
