﻿PREFABSCAN 3.0 — VISION PIPELINE

Zmiana architektury względem 2.x:
1. Kandydaci OCR nie są już agresywnie usuwani. Słabe oznaczenia pozostają do potwierdzenia przez drugi rysunek.
2. Każda studnia dostaje wynik dowodowy na podstawie lokalnych rzędnych, DN, rur, opisów studni i zwieńczeń.
3. PZT jest dzielone na lokalne komórki własności: liczby i rury trafiają przede wszystkim do najbliższej studni.
4. Rzędne mogą być ułożone pionowo lub poziomo przy oznaczeniu.
5. Profile odzyskują standardowy DN studni nawet jeśli OCR zgubi znak Ø/DN, ale tylko przy bardzo bliskiej wartości standardowej.
6. OCR renderuje większą stronę i korzysta z gęstszych, nakładających się kafli; cache ma nową wersję 3.0.0.
7. Nie zgadujemy typu ani zwieńczenia bez dowodu na rysunku. Niepewne obiekty są oznaczane do weryfikacji.

Cel: analiza jak przy ręcznym czytaniu profilu: obiekt -> lokalne otoczenie -> dane -> kontrola z drugim rysunkiem.
