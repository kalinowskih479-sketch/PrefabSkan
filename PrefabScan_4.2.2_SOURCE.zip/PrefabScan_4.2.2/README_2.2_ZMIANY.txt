﻿PrefabScan 2.2 — pakiet naprawczy OCR

Zmiany względem 2.1:
1. OCR cache ma nową wersję 2.2 — stare, słabe wyniki OCR nie będą ponownie używane.
2. Podstawowa skala OCR rysunków technicznych zwiększona z 1.75x do 2.15x.
3. Nadal wykonywane są przebiegi 0/90/270 stopni dla rysunków z małą liczbą kandydatów.
4. Dodany automatyczny przebieg ratunkowy OCR (PageSegMode.Auto, min. 2.6x), gdy pierwszy przebieg wykrywa <10 tokenów technicznych.
5. Wyniki wielu przebiegów są scalane geometrycznie przez istniejący Deduplicate(), więc nie powinny mnożyć tych samych oznaczeń.
6. Tytuł aplikacji: PrefabScan 2.2.

WAŻNE:
- Pierwsza analiza tych samych PDF po aktualizacji potrwa dłużej, bo cache OCR 2.1 jest celowo unieważniony.
- Kolejne uruchomienia użyją cache 2.2.
- Pakiet zachowuje dotychczasowe testy regresyjne D6/1, D7, D16, D5 DN2000 itd.

Walidacja w tym środowisku:
- wykonano kontrolę struktury źródeł i zmian;
- nie można uruchomić dotnet build/test, ponieważ środowisko robocze nie ma zainstalowanego polecenia dotnet.
- po rozpakowaniu na Windows uruchom Kompiluj > Kompiluj rozwiązanie, a następnie projekt SewerScan.UI.
